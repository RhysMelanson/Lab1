import java.util.ArrayList;

public class AddressBook {

    public ArrayList<BuddyInfo> AddressBook;

    public AddressBook() {
        AddressBook = new ArrayList<BuddyInfo>();


    }

    public void addBuddy(String name, String address, String phone){
        AddressBook.add(new BuddyInfo(name, address, phone));
    }

    public BuddyInfo removeBuddy(int num){

        return AddressBook.remove(num);
    }

    public String toString(){

        ArrayList<BuddyInfo> temp = AddressBook;

        String toString = "";

        while(!(temp.isEmpty())){
            BuddyInfo bud = temp.remove(0);
            toString = toString + " Contact: " + bud.getName() + " " + bud.getAddress() + " " + bud.getPhone();
        }

        return toString;
    }
}
