public class Main {

    public static void main(String[] args) {
        AddressBook add = new AddressBook();
        add.addBuddy("John","74 lane", "8372637263");
        add.addBuddy("Tim","98 Crecsent", "817328182");

        System.out.println(add.toString());

    }
}
