import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
@Entity
public class AddressBook {

    public ArrayList<BuddyInfo> AddressBook;
    public String id;

    public AddressBook() {

        AddressBook = new ArrayList<BuddyInfo>();

    }
    public AddressBook(String name) {
        id = name;
        AddressBook = new ArrayList<BuddyInfo>();


    }
    @Id
    public String getId(){
        return id;
    }

    public void setId(String name){
        id = name;
    }

    public void addBuddy(String name, String address, String phone){
        AddressBook.add(new BuddyInfo(name, address, phone));
    }

    public void addBuddy2(BuddyInfo bud){
        AddressBook.add(bud);
    }

    @OneToMany(mappedBy = "buddy")
    public ArrayList<BuddyInfo> getBuddies(){
        return AddressBook;
    }

    public BuddyInfo removeBuddy(int num){

        return AddressBook.remove(num);
    }

    public String toString(){

        ArrayList<BuddyInfo> temp = AddressBook;

        String toString = "";

        while(!(temp.isEmpty())){
            BuddyInfo bud = temp.remove(0);
            toString = toString + " Contact: " + bud.getName() + " " + bud.getAddress() + " " + bud.getPhone();
        }

        return toString;
    }
}
